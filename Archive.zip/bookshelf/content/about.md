+++
title = "About"
weight = 30
draft = false
+++

{{< figure class="image main" src="/images/pic03.jpg" >}}
Hi! I am Taufiq Mohammed, a 17 year old fuccboi
