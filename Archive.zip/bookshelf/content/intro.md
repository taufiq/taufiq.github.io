+++
title = "Intro"
weight = 10
draft = false
+++


{{< figure class="image main" src="/images/pic01.jpg" >}}
Hi! I am Taufiq Mohammed, a 17 year old student currently pursuing a diploma in Information Security and Forensics in Ngee Ann Polytechnic. I spend most of my free time learning about the latest trend in technology and programming. I am mostly an Android Developer and 
I have made 2 apps so far, one being a utility app for the SST Open House in the year of 2016, the other being an app for Paediatric Anesthaesiologists.
